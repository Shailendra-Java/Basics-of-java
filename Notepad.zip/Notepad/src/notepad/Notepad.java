package notepad;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.*;
public class Notepad implements ActionListener{

    JFrame frame;
    JMenuBar menuBar;
    JMenu file, edit, view, format, help, language;
    JMenuItem english, hindi, chinese, german, rusian;
    
    public void buildGui()
    {
        frame = new JFrame("Notepad");
        menuBar = new JMenuBar();
        
        file = new JMenu("File");
        edit = new JMenu("Edit");
        view = new JMenu("View");
        format = new JMenu("Format");
        help = new JMenu("Help");
        language = new JMenu("Language");
        
        english = new JMenuItem("English");
        hindi = new JMenuItem("Hindi");
        chinese = new JMenuItem("Chinese");
        german = new JMenuItem("German");
        rusian = new JMenuItem("Rusian");
        
        menuBar.add(file);
        menuBar.add(edit);
        menuBar.add(view);
        menuBar.add(format);
        menuBar.add(help);
        menuBar.add(language);
        
        language.add(english);
        language.add(hindi);
        language.add(chinese);
        language.add(german);
        language.add(rusian);
        
        english.addActionListener(this);
        hindi.addActionListener(this);
        chinese.addActionListener(this);
        german.addActionListener(this);
        rusian.addActionListener(this);
        
        ResourceBundle rbl1 = ResourceBundle.getBundle("com/Resource_en", new Locale("en","IN"));
        ResourceBundle rbl2 = ResourceBundle.getBundle("com/Resource_hi", new Locale("hi","IN"));
        ResourceBundle rbl3 = ResourceBundle.getBundle("com/Resource_zh", new Locale("zh","ZH"));
        ResourceBundle rbl4 = ResourceBundle.getBundle("com/Resource_de", new Locale("de","DE"));
        ResourceBundle rbl5 = ResourceBundle.getBundle("com/Resource_ru", new Locale("ru","RU"));
        
        english.setText(rbl1.getString("lang"));
        hindi.setText(rbl2.getString("lang"));
        chinese.setText(rbl3.getString("lang"));
        german.setText(rbl4.getString("lang"));
        rusian.setText(rbl5.getString("lang"));
        
        frame.setJMenuBar(menuBar);
        frame.setSize(800, 700);
        frame.setVisible(true);
    }
    
    public static void main(String[] args) {
       new Notepad().buildGui();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
       String languageCode = null;
       String countryCode = null;
       String resource = null;
        switch(ae.getActionCommand())
        {
            case "हिंदी":
                languageCode = "hi";
                countryCode = "IN";
                resource = "Resource_hi";
                break;
            case "Deutsche":
                languageCode = "de";
                countryCode = "DE";
                resource = "Resource_de";
                break;
            case "中文":
                languageCode = "zh";
                countryCode = "ZH";
                resource = "Resource_zh";
                break;
            case "русский":
                languageCode = "ru";
                countryCode = "RU";
                resource = "Resource_ru";
                break;
            case "English":
                languageCode = "en";
                countryCode = "IN";
                resource = "Resource_en";
                break;
                
        }
        ResourceBundle rbl = ResourceBundle.getBundle("com/"+resource, new Locale(languageCode,countryCode));
        file.setText(rbl.getString("file"));
        edit.setText(rbl.getString("edit"));
        view.setText(rbl.getString("view"));
        format.setText(rbl.getString("format"));
        help.setText(rbl.getString("help"));
        
    }
    
}
