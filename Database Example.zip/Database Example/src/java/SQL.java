
import java.sql.Connection;
import java.sql.DriverManager;

public class SQL {
    
    private static Connection connection;
    public static Connection getConnection(){
    
        try{
        
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","NIIT","niit@123"); 
            
        }catch(Exception exp)
        {
            System.err.println("Exception : "+exp);
        }
        return connection;
    }
}
